#Puppet Module for NGINX web server
###written by Mike Reider for practice
###Jan 20, 2016
--
sources used to build nginx module:

http://nginx.org/en/docs/beginners_guide.html

### Compatible Operating Systems:
CentOS/RedHat 6,7
Ubuntu 12,14

### Puppet Version compatibility
PE 3.8 and greater

### NOTICE:
if running SELinux for CentOS/Redhat/Fedora/Ubuntu/Debian, make sure to disable or lower to permissive, otherwise port 8000 wont bind correctly





